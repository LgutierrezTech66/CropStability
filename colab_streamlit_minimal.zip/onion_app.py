
import streamlit as st
import joblib
import numpy as np

model = joblib.load("rf_onion_model_with_water.pkl")

st.title("Onion Crop Stability Predictor")

soil_ph = st.slider("Soil pH", 5.5, 7.5, 6.5)
avg_temp = st.slider("Avg Temp (°C)", 10.0, 30.0, 20.0)
rainfall = st.slider("Rainfall (mm)", 0, 300, 150)
soil_nutrients = st.slider("Soil Nutrient Score", 0.0, 1.0, 0.8)
seasonal_variability = st.slider("Seasonal Variability Score", 0.0, 1.0, 0.2)
water_usage = st.slider("Water Usage (mm)", 300, 800, 500)

if st.button("Predict Crop Stability"):
    features = np.array([[soil_ph, avg_temp, rainfall, soil_nutrients, seasonal_variability, water_usage]])
    prediction = model.predict(features)[0]
    st.success(f"Predicted Crop Stability: {prediction:.2f}%")
